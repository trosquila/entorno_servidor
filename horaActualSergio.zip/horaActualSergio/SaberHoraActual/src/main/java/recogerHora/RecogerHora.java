package recogerHora;

import java.time.LocalTime;

public class RecogerHora {
	public LocalTime cogerHora() {
		LocalTime hora = LocalTime.now();
		return hora;
		
	}
}
