package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name = "notas")
public class NotasEntity {
	
	@Id
    @Column(name = "id")
    private int id;
	
	
    @Column(name = "id_alumnos")
    private String idAlumnos;
    
    
    @Column(name = "id_asignaturas")
    private String idAsignaturas;

    @Column(name = "notas")
    private String notas;

    @Column(name = "fecha")
    private String fecha;
    
    
}
